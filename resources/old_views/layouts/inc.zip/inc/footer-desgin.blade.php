<div class="pt-footer">
        <div class="container">
            <div class="row">
                <div class="pt-foot-ul">
                    <ul>
                        <li><a href="{{url('/designshirts')}}">CUSTOM SHIRTS</a></li>
                        <li> | </li>
                        <li><a href="{{url('/designjackets')}}">CUSTOM JACKETS </a></li>
                        <li> | </li>
                        <li><a href="{{url('/designpants')}}">CUSTOM PANTS </a></li>
                        <li> | </li>
                        <li><a href="{{url('/designvests')}}">CUSTOM VESTS</a></li>
                        <li> | </li>
                        <li><a href="{{url('pages/about-us')}}">ABOUT US</a></li>
                        <li> | </li>
                        <li><a href="{{url('/review')}}">REVIEW</a></li>
                        <li> | </li>
                        <li><a href="{{url('pages/contact-us')}}">CONTACT US</a></li>
                    </ul>
                </div>	 
            </div>
        </div>   
</div>