<section class="et-serivces et-page-navbar"><!-- Menu Section Start -->
    <div class="et-stuck-navbar">
        <div class="et-fix-nav float-panel">
            <div class="container">
                <div class="row" id="row-menu">
                  
                   <button class="et-menu-btn"><i class="fa fa-bars" aria-hidden="true"></i></button>
                        {!! Menu::display('page_menu') !!}
                 </div>
            </div>
        </div>
    </div>
</section><!-- Menu Section End -->