
 {!! Menu::display('footer_menu') !!}
               